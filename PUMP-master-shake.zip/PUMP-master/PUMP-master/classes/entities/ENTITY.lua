local Class = require("lib.Class")
local U = require("lib.Utils")

local ENTITY = Class:derive("ENTITY")

function ENTITY:new(...)
    self.components = {}
    local components_to_add = {...}
    
    if #components_to_add > 0 then
        for i = 1, #components_to_add do
            self:add(components_to_add[i])
        end
    end

    self.age = 0 -- age for all entities, in seconds

end

--helps us sort our priorities because priorities are important
local function priority_compare(e1, e2)
    return e1.priority < e2.priority
end

--Add a component to this entity
--
--Note: name is optional and if it is not used, the component's class type
--will be used instead
function ENTITY:add(component, name)
    if U.contains(self.components, component) then return end
    --Add additional table entries that we want to exist for all components
    
    --Let the component know who its parent is
    component.entity = self
    --higher priority components will be updated/drawn before lower priority ones
    component.priority = component.priority or 1
    --indicates if the on_started function has been called on a component
    component.started = component.started or false
    --if a component is enabled, then it is drawn/updated
    component.enabled = (component.enabled == nil) or component.enabled

    --Add the component to the list
    self.components[#self.components + 1] = component

    if name ~=nil and type(name) == "string" and name.len() > 0 then
        assert(self[name] == nil, "This entity already contains a component of name: " .. name)
        self[name] = component
    elseif component.type and type(component.type) == "string" then
        -- should we really not allow two of the same type???? -ross
        assert(self[component.type] == nil, "This entity already contains a component of type: " .. component.type)
        self[component.type] = component
    end

    -- if component.on_added then component:on_added() end

    if self.started and not component.started and component.enabled then
        component.started = true
        if component.on_start then component:on_start() end
    end
    
    --Sort components
    table.sort(self.components, priority_compare)
end

function ENTITY:remove(component)
    local i = U.index_of(self.components, component)
    if i == -1 then return end

    --if the component has an on_remove event, call it
    if component.on_remove then component:on_remove() end
    --then remove it
    table.remove(self.components, i)

    --check if the component has a type property of type string
    --if so, remove it from this entity
    if component.type and type(component.type) == "string" then
        self[component.type] = nil
        component.entity = nil -- this seems like it kiils the whole entity. maybe it removes the reference?
    end
end

function ENTITY:on_start()
    for i = 1, #self.components do
        local component = self.components[i]
        --if the component is enabled, then call on_start() if it has one
        if component.enabled then
            if not component.started then
                component.started = true
                if component.on_start then component:on_start() end
            end
        end
    end
end

function ENTITY:update(dt)


    -- C_update for inheritance
    if self.C_update then self:C_update(dt) end

    for i = 1, #self.components do
        --if the component is enabled, then update it
        if self.components[i].enabled and self.components[i].update then
            self.components[i]:update(dt)
        end
    end

    self.age = self.age + dt
    if self.age > 600000 then self.age = 20000 end -- prevent ages from going infinite when AFK

end

function ENTITY:draw()
    for i = 1, #self.components do
        if self.components[i].enabled and self.components[i].draw then
            self.components[i]:draw()
        end
    end
end

return ENTITY

-- anatomy of a component

--[[

    *** anatomy of a component

    ***DATA

    --self.components[i].enabled -- sets:
    
        1. if a component's :on_start() function gets called
            2. if the component id updated
        3. if the component is drawn
        
        -- self.components[i].started -- basically a flag to call the self.components[i]:on_start()
        
        ***FUNCTIONS

    self.components[i]:on_start() -- gets called once to initialize the component

    self.componente[i]:update()

    self.componente[i]:draw()

    self.components[i]:on_remove()

]]