
local scaleFactor = 3
function love.conf(t)

    -- thinkpad
    --t.window.width = 1050
    --t.window.height = 705
    --PC

    -- t.window.width = 900
    -- t.window.height = 900
    -- t.window.display = 1
    -- t.window.x = 100
    -- t.window.y = 100
    
    -- t.window.width = 320 * scaleFactor
    -- t.window.height = 240 * scaleFactor
    t.window.display = 1
    -- t.window.y = 20
    t.console = true

end